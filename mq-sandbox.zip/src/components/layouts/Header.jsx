import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import CreateDialog from "../exercises/dialogs/Create";
import AlertDialog from "../exercises/dialogs/Alert";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  menuButton: {
    marginRight: theme.spacing(2)
  },
  title: {
    flexGrow: 1
  }
}));

const Header = ({ muscles, onCreate }) => {
  const classes = useStyles();
  const [open, setOpen] = useState(false);

  const handleMenuOpen = () => {
    setOpen(true);
  }

  return (
    <div className={classes.root}>
      <div>
        <h1>React with Material UI</h1>
      </div>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            edge="start"
            className={classes.menuButton}
            color="inherit"
            aria-label="Menu"
            onClick={handleMenuOpen}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" className={classes.title}>
            Gym Exercise App
          </Typography>
          <CreateDialog muscles={muscles} onCreate={onCreate} />
        </Toolbar>
      </AppBar>
      <AlertDialog open={open} setOpen={setOpen} />
    </div>
  );
};

export default Header;
